<!DOCTYPE html>
<html>

<!-- Mirrored from www.Parking Koi.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Apr 2019 06:01:29 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Cache-control" content="public">
    <meta http-equiv="Cache-control" content="max-age=86400">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keyword" content="">

    <title>ParkingKoi | Unlocking Hidden Parkging Spaces</title>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src=""></script>
    <script>
        
    </script>

    <link rel="icon" href="<?php echo base_url()?>assets/images/Parking Koi.ico" type="image/x-icon">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/materialize.min.css" media="screen,projection" />
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/flexboxgrid.min.css" media="screen,projection" />
    <!-- Swiper Carousel CSS -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/swiper.min.css" media="screen,projection" />
    <!-- Animation CSS -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/animate.min.css" media="screen,projection" />
    <!-- Font CSS -->
    <link href="https://fonts.googleapis.com/css?family=Hind+Siliguri:300,400,500,600,700" rel="stylesheet">
    <link href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.css" />
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
    <!-- Main CSS -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css" media="screen,projection" />


      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--Let browser know website is optimized for mobile-->
    <style>
        #tabslider li.on {
            background: #f7f6f6;
            color: #09213A !important;
        }
    </style>
     <style>
        select {
            display: inline !important;
            border: 1px solid rgb(54, 74, 94) !important;
            margin-top: 30px;
        }

        .spn-cal {
            background-color: #f3c925;
            color: white;
            font-size: 50px;
            font-weight: bold;
            text-align: center;
            padding: 15px 30px 20px 30px;
            font-family: Calibri;
            margin-bottom:10px !important;
            display: inline-block;

        }

        .m-t-30 {
            margin-top: 113px !important;
        }
        #reve-chat-widget-header{
            width:100px !important;
                left: 0;
    bottom: 40px;
    position: fixed;
    z-index: 600;
    overflow: hidden;
    cursor: pointer;
    transform: rotate(90deg);
        }
        .pageHolder {
    width: 100%;
    
}

.leftImageOffline {
    border-right: none;
    padding-left: 3px;
    padding-right: 3px;
    width: 30px;
}

.leftImage, .leftImageOffline {
    height: 18px;
    color: #fff;
    text-align: center;
    padding: 6px 0;
    border-top-left-radius: 4px;
    border: 0;
    width: 39px;
    font-size: 20px;
}

.leftImage, .leftImageOffline {
    float: left;
    background-color: #FF5800;
    box-sizing: content-box;
}

.rightTextOffline {
    width: 100px !important;
}

.rightText, .rightTextOffline {
    padding-left: 0;
}

.rightText, .rightTextOffline {
    height: 30px;
    border-top-right-radius: 4px;
}

.rightTextOffline {
    float: left;
    background-color: #FF6C00;
    width: 240px;
    padding: 0 10px;
}
    </style>


</head>
<body class="banner">
    <a href="#" onclick="topFunction()" id="myBtn" title="Go to top">
        <img src="<?php echo base_url()?>assets/images/back-to-top.png" />
    </a>
    <!-- =========== Header ============ -->
    <header>
        <div class="container">
            <div class="row middle-xs">
                <!-- Logo -->
                <div class="col-sm-3 col-xs-6">
                    <div class="logo">
                        <!-- <a href="<?php //echo base_url()?>"><img src="<?php //echo base_url()?>assets/images/parkingkoi-logo.png" class="responsive-img" width="200" alt="logo" title="logo"></a> -->
                        <a href="<?php echo base_url()?>"><img src="<?php echo base_url()?>assets/images/gif.gif" class="responsive-img" width="200" alt="logo" title="logo"></a>
                    </div>
                </div>
                <!-- Logo -->
                <!-- Header Navigation (Desktop)-->
                <div class="col-sm-9 hide-on-small-only">
                    <div class="nav-bar right-align">
                        
                    </div>
                </div>
                <!-- Header Navigation (Desktop)-->
                <!-- Header Navigation (Mobile)-->
                <div class="col-xs-6 hide-on-med-and-up">
                    <div class="nav-wrapper nav-bar right-align">
                      

                    </div>
                </div>
                <!-- Header Navigation (Desktop)-->
            </div>
        </div>
    </header>
  
    <!-- =========== Header ============ -->